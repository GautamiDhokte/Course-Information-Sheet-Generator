<?php
						$dbhost='localhost:3306';
						$user="root";
						$pass="";
						$conn=mysql_connect($dbhost,$user,$pass);
if(!$conn)
{
	echo "<script>alert('Connection refused...');</script>";
}
						$rr=mysql_select_db('dbmsproject');
if(!$rr)
{
	echo "<script>alert('Could bot open database...');</script>";
}

?>